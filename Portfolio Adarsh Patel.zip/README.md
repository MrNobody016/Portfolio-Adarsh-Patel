
  # Minimalist Portfolio Website Template

  This is a code bundle for Minimalist Portfolio Website Template. The original project is available at https://www.figma.com/design/226U9mVBvnDDpQ2W9Z0kJU/Minimalist-Portfolio-Website-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  