import { motion } from 'motion/react';
import { Briefcase, GraduationCap, Award } from 'lucide-react';

interface TimelineItem {
  type: 'work' | 'education' | 'achievement';
  title: string;
  organization: string;
  period: string;
  description: string;
  icon: typeof Briefcase;
}

export function ExperienceSection() {
  const timeline: TimelineItem[] = [
    {
      type: 'education',
      title: 'Bachelor in Computer Applications (Media and IT)',
      organization: 'Ajeenkya DY Patil University, Pune',
      period: '2023 - 2026',
      description: 'Currently pursuing third year. Focusing on UI/UX design, web development, and media technologies. Building skills in design thinking and creative problem-solving.',
      icon: GraduationCap,
    },
    {
      type: 'work',
      title: 'UI/UX Designer & Prototyper',
      organization: 'Anime Relics E-Commerce App (Collaborative)',
      period: '2024',
      description: 'Designed the full mobile shopping experience in Figma—from initial mobile login to checkout. Organized the entire store structure (Information Architecture) for 6+ types of merchandise. Built an interactive, high-fidelity prototype showcasing seamless user experience.',
      icon: Briefcase,
    },
    {
      type: 'education',
      title: '12th Higher Secondary Education - Commerce',
      organization: 'Vasant Vihar High School and Junior College',
      period: '2021 - 2023',
      description: 'Scored 80% in Commerce stream. Developed strong analytical and problem-solving skills, laying the foundation for creative technology work.',
      icon: GraduationCap,
    },
  ];

  const getColorClasses = (type: string) => {
    switch (type) {
      case 'work':
        return {
          bg: 'bg-gradient-to-br from-teal-500/20 to-teal-600/20',
          icon: 'text-teal-400',
          border: 'border-teal-500/30',
        };
      case 'education':
        return {
          bg: 'bg-gradient-to-br from-blue-500/20 to-blue-600/20',
          icon: 'text-blue-400',
          border: 'border-blue-500/30',
        };
      case 'achievement':
        return {
          bg: 'bg-gradient-to-br from-orange-500/20 to-orange-600/20',
          icon: 'text-orange-400',
          border: 'border-orange-500/30',
        };
      default:
        return {
          bg: 'bg-gray-700/20',
          icon: 'text-gray-400',
          border: 'border-gray-600/30',
        };
    }
  };

  return (
    <section id="experience" className="py-24 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
      {/* Decorative gradient orbs */}
      <div className="absolute top-10 right-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-10 left-20 w-80 h-80 bg-indigo-500/20 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-white mb-4">Experience & Education</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-teal-400 to-purple-400 mx-auto rounded-full" />
          <p className="text-gray-300 mt-4 max-w-2xl mx-auto">
            My professional journey and educational background
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line - centered on desktop, left on mobile */}
            <div className="absolute left-8 md:left-1/2 md:-translate-x-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-teal-500/50 via-purple-500/50 to-blue-500/50" />

            {timeline.map((item, index) => {
              const colors = getColorClasses(item.type);

              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="relative mb-12 pl-24 md:pl-0"
                >
                  {/* Icon container - centered on the timeline */}
                  <div
                    className={`absolute left-0 md:left-1/2 md:-translate-x-1/2 w-16 h-16 ${colors.bg} rounded-full flex items-center justify-center border-4 ${colors.border} backdrop-blur-sm shadow-lg z-10`}
                  >
                    <item.icon className={colors.icon} size={24} />
                  </div>

                  {/* Content - on desktop, alternate left/right */}
                  <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:mr-auto md:pr-12' : 'md:ml-auto md:pl-12'}`}>
                    <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 shadow-md hover:shadow-xl hover:shadow-teal-500/10 transition-all duration-300 border border-gray-700/50 hover:border-teal-500/50">
                      <span className="text-sm text-teal-400 uppercase tracking-wide">
                        {item.period}
                      </span>
                      <h3 className="text-xl text-white mt-2 mb-1">
                        {item.title}
                      </h3>
                      <p className="text-gray-300 mb-3">
                        {item.organization}
                      </p>
                      <p className="text-gray-400 text-sm leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
