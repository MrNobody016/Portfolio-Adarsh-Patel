import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Github, X } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent } from './ui/dialog';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  category: string[];
  longDescription: string;
  technologies: string[];
  liveUrl: string;
  githubUrl: string;
}

export function ProjectsSection() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const projects: Project[] = [
    {
      id: 1,
      title: 'Anime Relics: E-Commerce Mobile App',
      description: 'UI/UX Design & Interactive Prototype for anime merchandise store',
      image: 'https://images.unsplash.com/photo-1750056393300-102f7c4b8bc2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzYyMzc0NDgxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: ['UI/UX', 'Mobile', 'E-Commerce'],
      longDescription: 'Designed the full mobile shopping experience in Figma—from the initial mobile login all the way through to a quick, painless checkout. Organized the entire store\'s structure (Information Architecture), creating clear categories for over 6 types of merchandise (like T-shirts, Hoodies, and Cosplay) to make product discovery simple and fun. Built the interactive, high-fidelity prototype that shows how users can seamlessly browse, view product details (including size selection), add items to the cart, and complete their purchase. My goal was simple: make finding awesome anime gear a joyful, engaging experience for fans.',
      technologies: ['Figma', 'Adobe XD', 'Prototyping', 'Wireframing', 'User Research'],
      liveUrl: 'https://shorturl.at/FyJNY',
      githubUrl: '#',
    },
  ];

  return (
    <section id="projects" className="py-24 bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Decorative gradient orbs */}
      <div className="absolute top-20 left-10 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-teal-500/20 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-white mb-4">Featured Projects</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-teal-400 to-purple-400 mx-auto rounded-full" />
          <p className="text-gray-300 mt-4 max-w-2xl mx-auto">
            A collection of my recent work spanning web applications, mobile apps, and creative solutions
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card
                className="overflow-hidden cursor-pointer group bg-gray-800/50 border border-gray-700/50 hover:border-teal-500/50 shadow-lg hover:shadow-2xl hover:shadow-teal-500/20 transition-all duration-300 backdrop-blur-sm"
                onClick={() => setSelectedProject(project)}
              >
                <div className="relative overflow-hidden h-64">
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <div className="p-6">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {project.category.map((cat) => (
                      <Badge key={cat} variant="secondary" className="bg-gradient-to-r from-teal-500/20 to-purple-500/20 text-teal-300 border border-teal-500/30">
                        {cat}
                      </Badge>
                    ))}
                  </div>
                  <h3 className="text-2xl text-white mb-2 group-hover:text-teal-400 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-300">{project.description}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Project Modal */}
      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
          {selectedProject && (
            <div className="space-y-6">
              <div className="relative h-80 rounded-lg overflow-hidden">
                <ImageWithFallback
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div>
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedProject.category.map((cat) => (
                    <Badge key={cat} variant="secondary" className="bg-gradient-to-r from-teal-500/20 to-purple-500/20 text-teal-300 border border-teal-500/30">
                      {cat}
                    </Badge>
                  ))}
                </div>
                <h3 className="text-3xl text-white mb-4">{selectedProject.title}</h3>
                <p className="text-gray-300 leading-relaxed mb-6">
                  {selectedProject.longDescription}
                </p>

                <div className="mb-6">
                  <h4 className="text-lg text-white mb-3">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.technologies.map((tech) => (
                      <Badge key={tech} className="bg-gray-800 text-gray-300 border border-gray-700">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <a
                    href={selectedProject.liveUrl}
                    className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-teal-500 to-purple-500 text-white rounded-lg hover:from-teal-600 hover:to-purple-600 transition-colors shadow-lg shadow-teal-500/20"
                  >
                    <ExternalLink size={18} />
                    View Live
                  </a>
                  <a
                    href={selectedProject.githubUrl}
                    className="flex items-center gap-2 px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-800 transition-colors"
                  >
                    <Github size={18} />
                    View Code
                  </a>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}