import { motion } from 'motion/react';
import {
  Code2,
  Palette,
  Database,
  Cloud,
  Smartphone,
  GitBranch,
  Layout,
  Zap,
} from 'lucide-react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

export function SkillsSection() {
  const skillCategories = [
    {
      title: 'Programming',
      icon: Code2,
      color: 'text-teal-400',
      bgColor: 'bg-teal-500/20',
      skills: [
        { name: 'Python', level: 80 },
        { name: 'Java', level: 75 },
        { name: 'HTML', level: 90 },
        { name: 'CSS', level: 88 },
        { name: 'JavaScript', level: 85 },
      ],
    },
    {
      title: 'UI/UX Design',
      icon: Palette,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20',
      skills: [
        { name: 'Figma', level: 95 },
        { name: 'Adobe XD', level: 88 },
        { name: 'Prototyping', level: 92 },
        { name: 'Wireframing', level: 90 },
        { name: 'User Research', level: 85 },
      ],
    },
    {
      title: 'Web Development',
      icon: Layout,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20',
      skills: [
        { name: 'Frontend Design', level: 88 },
        { name: 'Responsive Layouts', level: 90 },
        { name: 'Version Control (Git)', level: 82 },
      ],
    },
    {
      title: 'Data & Cloud',
      icon: Database,
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20',
      skills: [
        { name: 'AWS', level: 70 },
        { name: 'S3', level: 68 },
        { name: 'Databases (MySQL)', level: 75 },
      ],
    },
  ];

  const tools = [
    'Figma',
    'Adobe XD',
    'Git',
    'VS Code',
    'Python',
    'Java',
    'JavaScript',
    'HTML/CSS',
  ];

  return (
    <section id="skills" className="py-24 bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Decorative gradient orbs */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-white mb-4">Skills & Expertise</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-teal-400 to-purple-400 mx-auto rounded-full" />
          <p className="text-gray-300 mt-4 max-w-2xl mx-auto">
            Technical skills and tools I use to bring ideas to life
          </p>
        </motion.div>

        {/* Skill Categories */}
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto mb-16">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 hover:border-teal-500/50 rounded-xl p-8 shadow-lg hover:shadow-2xl hover:shadow-teal-500/10 transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-14 h-14 ${category.bgColor} rounded-lg flex items-center justify-center`}>
                  <category.icon className={category.color} size={28} />
                </div>
                <h3 className="text-2xl text-white">{category.title}</h3>
              </div>

              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <motion.div
                    key={skill.name}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: 0.6 + skillIndex * 0.1 }}
                  >
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-200">{skill.name}</span>
                      <span className="text-gray-400 text-sm">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700/50 rounded-full h-2 overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-teal-500 to-purple-500 rounded-full"
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.8 + skillIndex * 0.1, ease: "easeOut" }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tools & Technologies */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h3 className="text-2xl text-white mb-6">Tools & Technologies</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {tools.map((tool, index) => (
              <motion.div
                key={tool}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ scale: 1.1 }}
              >
                <Badge
                  variant="secondary"
                  className="px-4 py-2 text-base bg-gray-800/50 border border-gray-700/50 hover:border-teal-500 hover:bg-teal-500/20 text-gray-200 hover:text-teal-300 transition-all cursor-default"
                >
                  {tool}
                </Badge>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}