import { motion } from 'motion/react';
import { Download, MapPin, Mail, Briefcase } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function AboutSection() {
  const highlights = [
    { icon: Briefcase, text: 'UI/UX Designer & Prototyper' },
    { icon: MapPin, text: 'Pune, India' },
    { icon: Mail, text: 'adarsh.patel5061@gmail.com' },
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
      {/* Decorative gradient orbs */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-white mb-4">About Me</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-teal-400 to-purple-400 mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-teal-500 to-purple-500 rounded-2xl transform rotate-3" />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NjI0MjcwMDd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Professional portrait"
                className="relative rounded-2xl w-full h-[500px] object-cover shadow-2xl shadow-teal-500/20"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-6"
          >
            <h3 className="text-3xl text-white">
              Creative Innovator with a Passion for Technology
            </h3>
            <p className="text-gray-300 leading-relaxed">
              I'm a creative innovator with a deep passion for how technology and media intersect. 
              I blend design and storytelling to create impactful digital realities, consistently 
              approaching projects with focus, commitment, and a goal to shape the future.
            </p>
            <p className="text-gray-300 leading-relaxed">
              I'm skilled in design thinking, problem-solving, and creative communication, with a 
              strong focus on innovation and detail. I work well in collaborative environments, adapt 
              quickly, and continuously seek opportunities to learn and improve.
            </p>

            <div className="space-y-4 pt-4">
              {highlights.map((highlight, index) => (
                <motion.div
                  key={index}
                  className="flex items-center gap-3 text-gray-200"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.6 + index * 0.1 }}
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-purple-500 rounded-lg flex items-center justify-center">
                    <highlight.icon size={20} className="text-white" />
                  </div>
                  <span>{highlight.text}</span>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.9 }}
              className="pt-4"
            >
              <Button className="bg-gradient-to-r from-teal-500 to-purple-500 hover:from-teal-600 hover:to-purple-600 text-white px-6 py-6 rounded-lg shadow-lg shadow-teal-500/20">
                <Download size={18} className="mr-2" />
                Download Resume
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}